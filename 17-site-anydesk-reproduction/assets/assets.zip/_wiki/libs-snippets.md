##SCROLL TO with JQuery:

```js
	$(".header_menu").on("click", "a", function (event) { //находим нашу навигацию
		event.preventDefault(); 				//убираем дефолтное свойство ссылок
		var id = $(this).attr('href'),  //создаем переменную в которую вписываем значения внутри ссылок 
			top = $(id).offset().top;		  //используем метод offset() чтобы измерять пройденное расстояние начиная от верха
		$('body,html').animate({ scrollTop: top }, 1500); //добавляем плавность при опускании до секции
	});
```

#SCROLL TO SECTION LIBS

```js
	document.querySelectorAll('ul a[href^="#"]').forEach(function (anchor) {
	anchor.addEventListener('click', function (e) {
		e.preventDefault();
			smoothScroll.scrollTo(this.getAttribute('href'), 500);
	});
});
```

## SCROLL TO SECTION VANILLA

```js
	/**SCROLL TO SECTION VANILLA
	 ========================*/
	function scrollIt(element) {window.scrollTo({'behavior': 'smooth','left': 0,'top': element.offsetTop});}
		var btns = document.querySelectorAll('.js-btn');
		var sections = document.querySelectorAll('.js-section');
		btns[0].addEventListener('click', function () {scrollIt(sections[0]);});
		btns[1].addEventListener('click', function () {scrollIt(sections[1]);});//END SCROLL TO SECTION VANILLA
```
```html
<div class="btns">
		<button class="btn js-btn">Section 1</button>
		<button class="btn js-btn">Section 2</button>
</div>

<div class="section js-section">scroll-behavior: smooth - Section 1</div>
<div class="section js-section">scroll-behavior: smooth - Section 2</div>
```
===========================================

##MOBILE - NAVBAR VANILLA:

```js
	let hamburger = document.querySelector(".hamburger");
	let headerMenu = document.querySelector(" ");
	let headerMenuLinks = headerMenu.querySelectorAll(" ");
	hamburger.addEventListener("click", function (event) {
		event.preventDefault();
		this.classList.toggle("is-active");
		headerMenu.classList.toggle(" ");
	})

	for (let i = 0; i < headerMenuLinks.length; i++) {
		headerMenuLinks.addEventListener("click", function (event) {
		hamburger.classList.remove("is-active");
		headerMenu.classList.remove(" ");
	})}


```
=============================================

## HIDE NAVIGATION ON SCROLL DOWN VANILLA

```css 
.header {
	position: fixed;
	transition: top 0.3s ease;
}
```

```js
	/**HIDE NAVBAR WITH SCROLL
	 ========================*/
	var prevScrollpos = window.pageYOffset;
	window.onscroll = function () {
		var currentScrollPos = window.pageYOffset;
		if (prevScrollpos > currentScrollPos) {
			document.querySelector(".header").style.top = "0";
		} else {
			document.querySelector(".header").style.top = "-90px";
		}
		prevScrollpos = currentScrollPos;
	} 
```

=============================================

## OWL - CAROUSEL

```html
<div class="slider_inner owl-carousel owl-theme">
	<div class="slide_item"><img src="img/sl1.jpg" alt=""></div>
	<div class="slide_item"><img src="img/sl1.jpg" alt=""></div>
	<div class="slide_item"><img src="img/sl1.jpg" alt=""></div>
	<div class="slide_item"><img src="img/sl1.jpg" alt=""></div>
</div>
```

```js
$('.className').owlCarousel({
		loop: true,
		margin: 10,
		dots: true,
		nav: true,
		navText: [
			'<img src="...." alt="">',
			'<img src="...." alt="">'
		],
		responsive: {
			0: {
				items: 1
			},
			576: {
				items: 1
			},
			768: {
				items: 1
			},
			992: {
				items: 1
			},
			1200: {
				items: 1
			}
		}
	}); 
```

```css
.className {
	/* DOTS */
	.owl-theme .owl-dots {
		position: absolute;
		width: 100%;
		max-width: 9rem;
		display: flex;
		justify-content: space-between;
		top: 50%;
		left: 48%;
		transform: translate(-50%, -50%);
		text-align: center;
	}
	.owl-dot span {
		display: none;
	}
	.owl-dot {
		width: 1.5rem;
		height: 1.5rem;
		border-radius: 50%;
		border: 2px solid rgba(255, 255, 255, 0.7);
		transition: $trn;
		&:hover {
			background-color: #ffffff;
		}
		&.active {
			background-color: #ffffff;
		}
	}
	/* NAVIGATION */
	.owl-theme .owl-nav {
			margin: 0;
	}
	.owl-theme .owl-nav [class*='owl-'] {
			position: absolute;
			left: 0;
			top: 30%;
			left: 20px;
			-webkit-transform: translateY(-50%);
			transform: translateY(-50%);
	}
	.owl-theme .owl-nav [class*='owl-']:hover {
			background: transparent;
	}
	.owl-carousel .owl-nav button.owl-next {
			left: auto;
			right: 20px;
	}
}
.owl-theme .owl-nav.disabled+.owl-dots {
	margin-top: 0;
}
```

##NUMBER DOTS

```js
var dot = $('.hero_inner .owl-dot');
dot.each(function() {
	var index = $(this).index() + 1;
	if(index < 10){
		$(this).html('0').append(index);
	}else{
			$(this).html(index);
	}
});
```
=============================================

##SIEMA SLIDER

```html 
<div class="siema">
  <img src="https://pawelgrzybek.com/siema/assets/siema--pink.svg" alt="Siema image" />
  <img src="https://pawelgrzybek.com/siema/assets/siema--yellow.svg" alt="Siema image" />
  <img src="https://pawelgrzybek.com/siema/assets/siema--pink.svg" alt="Siema image" />
  <img src="https://pawelgrzybek.com/siema/assets/siema--yellow.svg" alt="Siema image" />
</div>
```

```css
.dots {
  display: flex;
  justify-content: center;
}

.dots__item {
  width: 1rem;
  height: 1.2rem;
  background-color: rgba(245, 245, 245, 0.5);
  margin: 0 .5rem;
  border: 0;
  border-radius: 50%;
  outline: 0;
  cursor: pointer;
}

.dots__item--active {
  background-color: #f5f5f5;
}
```

```js
class SiemaWithDots extends Siema {
	addDots() {
		this.dots = document.createElement('div');
		this.dots.classList.add('dots');
		for (let i = 0; i < this.innerElements.length; i++) {
			const dot = document.createElement('button');
			dot.classList.add('dots__item');
			dot.addEventListener('click', () => {
				this.goTo(i);
			})
			this.dots.appendChild(dot);
		}
		this.selector.parentNode.insertBefore(this.dots, this.selector.nextSibling);
	}
	updateDots() {
		for (let i = 0; i < this.dots.querySelectorAll('button').length; i++) {
			const addOrRemove = this.currentSlide === i ? 'add' : 'remove';
			this.dots.querySelectorAll('button')[i].classList[addOrRemove]('dots__item--active');
		}
	}
}
const mySiemaWithDots = new SiemaWithDots({
	onInit: function () {
		this.addDots();
		this.updateDots();
	},
	onChange: function () {
		this.updateDots()
	},
});

```

=============================================


## LightBox

```html
<a href="images.png" data-lightbox="roadtrip"><img src="images.png" alt=""></a>
```

```js
	lightbox.option({'resizeDuration': 200,'wrapAround': true	});
```

=============================================


##SCROLL TO TOP

```html
	<!--в href добавляем секцию куда будет вести кнопка по нажатию-->
	<a href="#header" class="btn_up"> 
		<!--для создания иконки-стрелки, можно добавить картинку-->
		<span class="top"></span>
		<span class="bottom"></span>
	</a>

```
```css

.btn_up {
  display: block;
  position: fixed;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  box-shadow: 0px 0px 3px 2px #fff;
  background-color: rgba(108, 108, 108, 0.61);
  bottom: 10%;
  right: 5%;
  transition: all 0.2s ease;
}
.btn_up span {
  position: absolute;
  content: "";
  display: block;
  width: 14px;
  height: 2px;
  background-color: #fff;
  left: 50%;
  top: 45%;
  transform: translate(-50%, -50%);
}
.btn_up .top {
  transform: rotate(45deg);
  left: 45%;
  border-bottom-right-radius: 2px;
  border-top-right-radius: 2px;
}
.btn_up .bottom {
  transform: rotate(-45deg);
  left: 28%;
  border-bottom-left-radius: 2px;
  border-top-left-radius: 2px;
}
.btn_up:hover {
  box-shadow: 0px 0px 3px 2px #fcac45;
}

```
```js

	$(".btn_up").hide(); //сначало скрываем кнопку на первом экране

	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) { //при скролле больше 100px 
				$(".btn_up").fadeIn();				 // показываем нашу кнопку
			}
			else {
				$(".btn_up").fadeOut();				// или скрываем
			}
		});
	});
	$(".btn_up").click(function () {	//при клике на кнопку
		$("body, html").animate({				// добавляем анимацию
			scrollTop: 0
		}, 800); 												// плавность анимации
		return false;
	});

```









=============================================
## COUNT NUMBER(счетчик)
```js
	/** COUNT NUMBER
	 ====================*/

	$('.count .number').each(function () { 
		$(this).prop('Counter',0).animate({
			Counter: $(this).text()
		}, {
			duration: 6000,
			easing: 'swing',
			step: function (now) {
				$(this).text(Math.ceil(now));
			}
		})
	}) 
```
=============================================

##SLIDER(ПОЛЗУНКИ) UI JQUERY
```js
	$( "#slider-range" ).slider({
		step: 50,
	 range: true,
	 min: 100,
	 max: 5000,
	 values: [ 100, 3000 ],
	 slide: function( event, ui ) {
		 $( "#amount_min" ).val(ui.values[ 0 ] );
		 $( "#amount_max" ).val(ui.values[ 1 ] );
	 }
 });
 $( "#amount_min" ).val($( "#slider-range" ).slider( "values", 0 ) );
 $( "#amount_max" ).val($( "#slider-range" ).slider( "values", 1 ) );
// Изменение местоположения ползунка при вводиде данных в первый элемент input
	 $("input#amount_min").change(function(){
		 var value1=$("input#amount_min").val();
		 var value2=$("input#amount_max").val();
			 if(parseInt(value1) > parseInt(value2)){
			 value1 = value2;
			 $("input#amount_min").val(value1);
		 }
		 $("#slider-range").slider("values",0,value1);	
	 });
	 // Изменение местоположения ползунка при вводиде данных в второй элемент input 	
	 $("input#amount_max").change(function(){
		 var value1=$("input#amount_min").val();
		 var value2=$("input#amount_max").val();
		 if(parseInt(value1) > parseInt(value2)){
			 value2 = value1;
			 $("input#amount_max").val(value2);
		 }
		 $("#slider-range").slider("values",1,value2);
	 });
// Фильтр
$("#amount_min,#amount_max").keypress(function(event){
var key, keyChar;
if(!event) var event = window.event;
if(event.keyCode) key = event.keyCode;
else if (event.which) key = event.which;
if(key==null || key==0 ||key==8 ||key==13 ||key==46 ||key==37 ||key==39)
 return true;
keyChar = String.fromCharCode(key);
if(!/\d/.test(keyChar)) return false;
})

```