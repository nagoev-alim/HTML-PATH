
/*================= ABSOLUTE POSITIONING ==========
div {
   @include abs-position(100px, 100px, auto, auto);
}
=============================================*/
@mixin pos-abs ($top, $right, $bottom, $left) {
	position: absolute;
	content: '';
	top: $top;
	right: $right;
	bottom: $bottom;
	left: $left;
}

/*================= ARROW WITH FOUR OPTIONAL DIRECTIONS ================
*
// without arguments (default)
div {
   @include arrow();
}

// with custom arguments
div {
   @include arrow(up, 10px, #efefef);
}
=============================================*/

@mixin arrow($direction: down, $size: 5px, $color: #555) {
	width: 0;
	height: 0;

	@if ($direction==left) {
		border-top: $size solid transparent;
		border-bottom: $size solid transparent;
		border-right: $size solid $color;
	}

	@else if ($direction==right) {
		border-top: $size solid transparent;
		border-bottom: $size solid transparent;
		border-left: $size solid $color;
	}

	@else if ($direction==down) {
		border-left: $size solid transparent;
		border-right: $size solid transparent;
		border-top: $size solid $color;
	}

	@else {
		border-left: $size solid transparent;
		border-right: $size solid transparent;
		border-bottom: $size solid $color;
	}
}



/*==================== SIZE ELEMENT ==========
* (https://sass-compatibility.github.io/#list_separator_function)

$base-font-size: 16px;
$h1-font-size: 24px;
h1 {
  font-size: em($h1-font-size, $base-font-size);
  border-bottom: em(1px solid black, $h1-font-size);
  box-shadow: em(0 0 2px #ccc, inset 0 0 5px #eee, $h1-font-size);

  @include em((margin: 20px 5%,padding: 10px), $h1-font-size);
}
=============================================*/

@function em-separator($list) {
	@if function-exists("list-separator")==true {
		@return list-separator($list);
	}

	$test-list: ();

	@each $item in $list {
		$test-list: append($test-list, $item, space);
	}

	@return if($test-list==$list, space, comma);
}

@function em($values...) {
	$context: nth($values, length($values));
	$result: ();
	$separator: em-separator($values);

	@for $i from 1 through length($values) - 1 {
		$value: nth($values, $i);

		@if type-of($value)=="number"and unit($value)=="px" {
			$result: append($result, $value / $context * 1em, $separator);
		}

		@else if type-of($value)=="list" {
			$result: append($result, em(append($value, $context)...), $separator);
		}

		@else {
			$result: append($result, $value, $separator);
		}
	}

	@return if(length($result)==1, nth($result, 1), $result);
}

@mixin em($properties, $context) {
	@each $property in map-keys($properties) {
		#{$property}: em(append(map-get($properties, $property), $context)...);
	}
}


// =========== Typography Fluid ==============
/*
Example (https://habr.com/post/310186/?mobile=no)
.item {
	@include fluidFontSize(16px, 24px, 480px, 1280px, 18px);
}
*/

@function strip-unit($number) {
	@if type-of($number)=='number'and not unitless($number) {
		@return $number / ($number * 0 + 1);
	}

	@return $number;
}

@function calcFluidFontSize($f-min, $f-max, $w-min, $w-max: 1170px, $units: px) {
	$f-min: strip-unit($f-min);
	$f-max: strip-unit($f-max);
	$w-min: strip-unit($w-min);
	$w-max: strip-unit($w-max);

	$k: ($f-max - $f-min)/($w-max - $w-min);
	$b: $f-min - $k * $w-min;

	$b: $b + $units;

	@return calc(#{$k} * 100vw + #{$b});
}

@mixin fluidFontSize($f-min, $f-max, $w-min, $w-max, $fallback: false) {

	font-size: $f-min;

	@media (min-width: $w-min) {
		@if ($fallback) {
			font-size: $fallback;
		}

		font-size: calcFluidFontSize($f-min, $f-max, $w-min, $w-max, px);
	}

	@media (min-width: $w-max) {
		font-size: $f-max;
	}
}


// =========== Desktop First ==============

$screen-sm-min: 576px;
$screen-md-min: 768px;
$screen-lg-min: 992px;
$screen-xl-min: 1200px;

@mixin dsm {
	@media (max-width: #{$screen-sm-min}) {
		@content;
	}
}

@mixin dmd {
	@media (max-width: #{$screen-md-min}) {
		@content;
	}
}

@mixin dlg {
	@media (max-width: #{$screen-lg-min}) {
		@content;
	}
}

@mixin dxl {
	@media (max-width: #{$screen-xl-min}) {
		@content;
	}
}
