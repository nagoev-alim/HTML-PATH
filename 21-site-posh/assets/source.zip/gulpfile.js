const requireDir = require('require-dir');

const dir = requireDir('./gulp/tasks', { recurse: true });
