# Posh - сайт салона красоты

***Posh - «Красота по-королевски» — лаконичный девиз салона «Posh», как нельзя лучше отражает любовь и трепетное отношение к работе и к каждой гостье. Чарующие звуки живой фортепианной музыки в исполнении молодого музыканта за белым роялем приятно удивляет любого, кто впервые оказывается здесь.***
1. Made HTML-markup of all pages and all elements on the pages.
2. One style file for all pages.
3. Optimized the entire schedule.
4. Implementation of the mobile menu using vanilla JavaScript, slider using Swiper, filter using MixItUp.
5. The document is being tested for validity [http://validator.w3.org](http://validator.w3.org/)
6. Adaptive layout is implemented using media queries.
7. Google Lighthouse: Performance - 80+; Accessibility - 90+;
<p><img src="https://repository-images.githubusercontent.com/195103944/2e4ff180-9eae-11e9-91f7-3ff617303318" alt="Posh - сайт салона красоты"></p>