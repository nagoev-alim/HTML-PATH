// INVOKED FUNCTION
(function () {
	// mobile menu
	const [hamburger, menu] = [document.querySelector('.hamburger'), document.querySelector('.menu')]
	// events
	hamburger.addEventListener('click', () => {
		hamburger.classList.toggle('is-active');
		menu.classList.toggle('menu--open');
	})
	//-------------------------------------------
	// scroll to section
	const headerNavLinks = document.querySelectorAll('.menu__link');
	// events
	headerNavLinks.forEach(function (target) {
		target.addEventListener('click', function (e) {
			e.preventDefault();
			smoothScroll.scrollTo(this.getAttribute('href'), 800);
			menu.classList.remove('menu--open');
			hamburger.classList.remove('is-active')
		})
	})
	//-------------------------------------------
})();