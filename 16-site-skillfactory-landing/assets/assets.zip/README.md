# SkillFactory - школа по работе с данными

***Школа по работе с данными Skillfactory ★ SkillFactory: обучение Big Data, Data Science, Machine Learning, Data Engineering и AI ☎ +7 (495) 291-09-12***
1. Made HTML-markup of all pages and all elements on the pages.
2. One style file for all pages.
3. Optimized the entire schedule.
4. Implementation of the mobile menu using vanilla JavaScript, slider using SwiperJS.
5. The document is being tested for validity [http://validator.w3.org](http://validator.w3.org/)
6. Adaptive layout is implemented using media queries.
7. Google Lighthouse:
	index.html - Performance - 80+; Accessibility - 90+;
	experts.html - Performance - 90+; Accessibility - 90+;
<p><img src="https://repository-images.githubusercontent.com/193087925/afa5ab00-95b5-11e9-9a16-7c09241080b8" alt="SkillFactory - школа по работе с данными"></p>
