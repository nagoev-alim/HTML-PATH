```js

// SCROLL TO SECTION
const scrollToSection = (function () {
	const hamburger = document.querySelector('.hamburger');
	const menu = document.querySelector('.menu');
	var headerNavLinks = document.querySelectorAll('.menu__link');
	// events
	headerNavLinks.forEach(function (target) {
		target.addEventListener('click', function (e) {
			e.preventDefault();
			smoothScroll.scrollTo(this.getAttribute('href'), 800);
			menu.classList.remove('menu_open');
			hamburger.classList.remove('is-active')
		})
	})

})();
scrollToSection;


// HIDE NAVBAR WITH SCROLL ==========================
const hideOrShow = (function () {
	let prevScrollPosition = window.pageYOffset;
	window.onscroll = function () {
		let currentScrollPosition = window.pageYOffset;
		if (prevScrollPosition > currentScrollPosition) {
			document.querySelector(".nav").style.top = "0";
		} else {
			document.querySelector(".nav").style.top = "-70px";
		}
		prevScrollPosition = currentScrollPosition;
	};
})();
hideOrShow;

// ADD FIXED NAVIGATION
const fixedNav = (function () {
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		document.body.scrollTop > 1 ||
			document.documentElement.scrollTop > 1 ? document.querySelector('.nav').classList.add('nav_fixed') :
			document.querySelector('.nav').classList.remove('nav_fixed')
	}
})();
fixedNav;

```